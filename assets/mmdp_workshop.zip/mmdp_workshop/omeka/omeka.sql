create database omeka;
grant all privileges on omeka.* to 'vagrant'@'localhost' identified by 'omeka';
flush privileges;